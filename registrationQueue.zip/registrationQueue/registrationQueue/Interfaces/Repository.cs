﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace registrationQueue.Interfaces
{
    public interface IRepository<TEntity> where TEntity : class
    {
        List<TEntity> GetAll();
        List<TEntity> GetAll(string sec);
        TEntity Get(int id);
        TEntity Get(string sec, int id);
        int Insert(TEntity entity);
        int Insert(string sec, TEntity entity);
        int Update(TEntity entity);
        int Update(string sec, TEntity entity);
        int Delete(string name);
        int Delete(string sec, string name);
        List<TEntity> GetByUserName(string username);
        TEntity Get(string username);
    }
}
