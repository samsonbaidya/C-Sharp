﻿using registrationQueue.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace registrationQueue.UI_Layer
{
    public partial class StudentHome : Form
    {
        string username;
        LoginForm loginForm;
        public StudentHome(LoginForm loginForm,string username)
        {
            InitializeComponent();
            this.loginForm = loginForm;
            this.username = username;
            label1.Text = "Hello "+ username + " Welcome To The Registration Panel";
        }

        private void Registration_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            loginForm.Show();
            this.Hide();
        }
        private void seeQueueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RegistrationQueue registrationQueue = new RegistrationQueue(this);
            this.Hide();
            registrationQueue.Show();
        }

        private void ChooseCourseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RegistrationCourse regCourse = new RegistrationCourse(this,this.username);
            this.Hide();
            regCourse.Show();
        }

        private void RegisteredCourseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RegisteredCourse registeredCourse = new RegisteredCourse(username,this);
            this.Hide();
            registeredCourse.Show();
        }
    }
}
