﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace registrationQueue.UI_Layer
{
    public partial class AdminHome : Form
    {
        LoginForm loginForm;
        QueueManagement queueManagement;
        CourseManagement courseManagement;
        public AdminHome(LoginForm loginForm)
        {
            InitializeComponent();
            this.loginForm = loginForm;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            loginForm.Show();
            this.Hide();
        }
        private void queueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            queueManagement = new QueueManagement(this);
            this.Hide();
            queueManagement.Show();
        }

        private void AdminHome_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void cSectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            courseManagement = new CourseManagement(this);
            this.Hide();
            courseManagement.Show();
        }

    }
}
