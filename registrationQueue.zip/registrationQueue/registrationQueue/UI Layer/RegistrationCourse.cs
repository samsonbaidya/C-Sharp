﻿using registrationQueue.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace registrationQueue.UI_Layer
{
    public partial class RegistrationCourse : Form
    {
        int selectedRow;
        CourseService courseService;
        SectionService sectionService;
        RegistrationService regService;
        QueueService queueService;
        int courseId;
        int secId;
        StudentHome studHome;
        string username;
        public RegistrationCourse(StudentHome studHome,string username)
        {
            InitializeComponent();
            this.courseService = new CourseService();
            this.sectionService = new SectionService();
            this.regService = new RegistrationService();
            this.queueService = new QueueService();
            this.studHome = studHome;
            this.username = username;
        }
        void ClearText()
        {
             textBox1.Text = textBox2.Text = string.Empty;
        }
        void UpdateGridView()
        {
            dataGridView1.DataSource = regService.GetRegistrationByUsername(username);
            dataGridView1.Columns[0].Visible = false;
            dataGridView1.Columns[1].Visible = false;
        }
        private void comboBox1_Click(object sender, EventArgs e)
        {
            comboBox1.DataSource = courseService.GetAllCourseNames();
            comboBox2.Enabled = true;
        }

        private void comboBox2_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "select course...")
            {
                comboBox2.Enabled = false;
            }
            else
            {
                try
                {
                    comboBox2.DataSource = sectionService.GetAllSectionNames(comboBox1.Text);
                }
                catch
                {
                    MessageBox.Show("Invalid course name.");
                    comboBox2.Enabled = false;
                }
                
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int result1 = queueService.QueueValidation(username);
            if (result1 > 0)
            {
                MessageBox.Show("You are not allowed to add any course ,while you are in line , read the instructions properly.");
            }
            else
            {
                if (comboBox2.Enabled == true && comboBox2.Text != "select section...")
                {
                    try
                    {
                        courseId = courseService.GetIdByName(comboBox1.Text);
                        secId = sectionService.GetIdBySection(comboBox1.Text, comboBox2.Text);

                        int result = regService.RegistrationValidation(username, comboBox1.Text);

                        if (result > 0)
                        {
                            MessageBox.Show("You are not allowed to stand for the same course twice, you may choose another course.");
                        }
                        else
                        {
                            result = regService.RegistrationMethod(username, comboBox1.Text, comboBox2.Text);
                            if (result > 0)
                            {
                                comboBox1.Text = "select course...";
                                comboBox2.Text = "select section...";
                                UpdateGridView();
                            }
                            else
                            {
                                MessageBox.Show("Error");
                            }
                        }

                    }
                    catch
                    {
                        MessageBox.Show("Invalid section name.");
                        comboBox2.Enabled = false;

                    }

                }
                else
                {
                    MessageBox.Show("Please select your course and section properly.");
                }
            }
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            DialogResult dresult = MessageBox.Show("Are you sure?", "Confirmation", MessageBoxButtons.YesNo);
            if (dresult == DialogResult.Yes)
            {
                button3.Enabled = false;
                int result = regService.RemoveRegistration(textBox1.Text);
                if (result > 0)
                {
                    MessageBox.Show("Course deleted successfully.");
                    UpdateGridView();
                    ClearText();
                }
                else
                {
                    MessageBox.Show("Error occured..");
                    ClearText();
                }
            }
            ClearText();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int result1 = regService.RegistrationValidationUser(username);
            if(result1 > 0)
            {
                button5.Enabled = true;
                int result = queueService.QueueValidation(username);
                if (result > 0)
                {
                    MessageBox.Show("You are already in the line, please be patient.");
                    panel2.Visible = true;
                }
                else if (panel2.Visible == false)
                {
                    panel2.Visible = true;
                    result = queueService.AddQueue(username);

                }
                else
                {
                    button4.Enabled = false;
                }
            }
            else
            {
                MessageBox.Show("Please choose atleast one course to stand in the line.");
            }

            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
          this.Hide();
          studHome.Show();
           
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int result1 = queueService.QueueValidation(username);
            if(result1 > 0)
            {
                DialogResult dresult = MessageBox.Show("Are you sure you want to leave the line ? All your selected course will be lost.", "Confirmation", MessageBoxButtons.YesNo);
                if (dresult == DialogResult.Yes)
                {
                 /*   try
                    {*/
                        panel2.Visible = false;
                        button1.Enabled = true;
                        button3.Enabled = true;
                        int result = queueService.RemoveQueue(username);
                        int result2 = regService.RemoveRegistrationByUserName(username);
                        if (result > 0 && result2 > 0)
                        {
                            MessageBox.Show("Opps !! You stand out of the line.");
                            UpdateGridView();
                        }
                        else
                        {
                            MessageBox.Show("Error");
                        }
                   /* }
                    catch
                    {
                        MessageBox.Show("you are not in the line");
                    }*/
                }
            }
            else
            {
                MessageBox.Show("you are not in the line yet.");
            }

        }

        private void RegistrationCourse_Load(object sender, EventArgs e)
        {
            UpdateGridView();
        }

        private void RegistrationCourse_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
            
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1)
            {
                
            }
            else
            {
                selectedRow = e.RowIndex;
                button3.Enabled = true;
                textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            }
        }
    }
}
