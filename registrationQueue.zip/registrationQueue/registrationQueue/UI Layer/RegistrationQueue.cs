﻿using registrationQueue.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace registrationQueue.UI_Layer
{
    public partial class RegistrationQueue : Form
    {
        StudentHome studHome;
        QueueService queueService;
        public RegistrationQueue(StudentHome studHome)
        {
            InitializeComponent();
            this.studHome = studHome;
            this.queueService = new QueueService();
        }

        private void RegistrationQueue_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = queueService.GetAllQueue();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            studHome.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = queueService.GetAllQueue();
        }

        private void RegistrationQueue_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
