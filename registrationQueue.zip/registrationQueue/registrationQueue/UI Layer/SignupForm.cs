﻿using registrationQueue.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace registrationQueue.UI_Layer
{
    public partial class SignupForm : Form
    {
        SignupService signupService;
        LoginForm loginForm;
        public SignupForm(LoginForm loginForm)
        {
            InitializeComponent();
            textBox3.MaxLength = 11;
            textBox4.MaxLength = 10;
            textBox5.PasswordChar = '*';
            this.signupService = new SignupService();
            this.loginForm = loginForm;
        }

        private void SignupForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            int type = 0;
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "")
            {
                MessageBox.Show("Field Required");
            }
            else
            {
                if (radioButton1.Checked == true)
                {
                    type = 1;
                }
                else if (radioButton2.Checked == true)
                {
                    type = 2;
                }
                else if (radioButton1.Checked == false && radioButton2.Checked == false)
                {
                    type = 0;
                }
                else
                {
                    MessageBox.Show("Error");
                }

                if (type > 0)
                {
                    try
                    {
                        int result = signupService.UserRegistration(textBox1.Text, textBox2.Text, Convert.ToInt32(textBox3.Text), textBox4.Text, textBox5.Text, type);
                        if (result > 0)
                        {
                            MessageBox.Show("User registration successfull.");
                            loginForm = new LoginForm();
                            this.Hide();
                            loginForm.Show();

                        }
                        else if (result == -1)
                        {
                            MessageBox.Show("You donot have the privilige to signup as admin");
                        }
                        else if (result == -2)
                        {
                            MessageBox.Show("You are not allowed to register here , this apps is only for Aiub Student's or Make sure that your Username is in correct format");
                        }

                        else
                        {
                            MessageBox.Show("Error");
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Type your phone no in correct format.");
                    }
                   
                }
                else
                {
                    MessageBox.Show("Check either Student or Admin to complete signup");
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            loginForm.Show();
        }
    }
}
