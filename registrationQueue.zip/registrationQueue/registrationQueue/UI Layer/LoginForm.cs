﻿using registrationQueue.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace registrationQueue.UI_Layer
{
    public partial class LoginForm : Form
    {
        LoginService loginService;
        public LoginForm()
        {
            InitializeComponent();
            loginService = new LoginService();
            textBox1.MaxLength = 10;
            textBox2.PasswordChar = '*';
        }

        private void LoginForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Username or Password can not be empty");
            }
            else
            {
                try 
                {
                    int result = loginService.LoginValidation(textBox1.Text, textBox2.Text);
                    if (result > 0)
                    {
                        if (result == 1)
                        {
                            AdminHome adminHome = new AdminHome(this);
                            this.Hide();
                            adminHome.Show();
                        }
                        else if (result == 2)
                        {
                            StudentHome studentHome = new StudentHome(this, this.textBox1.Text);
                            this.Hide();
                            studentHome.Show();
                        }
                        else
                        {
                            MessageBox.Show("You do not have the priviledge");
                        }


                    }
                    else
                    {
                        MessageBox.Show("Login Failed");
                    }
                }
                catch
                {
                    MessageBox.Show("Account not found please signup to continue or make sure that you username and password is correct.");
                }
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            SignupForm signupForm = new SignupForm(this);
            this.Hide();
            signupForm.Show();

        }

    }
}
