﻿using registrationQueue.Entities;
using registrationQueue.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace registrationQueue.UI_Layer
{
    public partial class QueueManagement : Form
    {
        QueueService queueService;
        AdminHome adminHome;
        RegistrationService registrationService;
       // CourseService courseService;
        SectionService sectionService;
        RegisteredService registeredService;
        string username;
        public QueueManagement(AdminHome adminHome)
        {
            InitializeComponent();
            this.queueService = new QueueService();
            this.adminHome = adminHome;
            registrationService = new RegistrationService();
            sectionService = new SectionService();
            registeredService = new RegisteredService();
        }
        void UpdateGridView()
        {
            dataGridView1.DataSource = queueService.GetAllQueue();
            dataGridView2.DataSource = registrationService.GetRegistrationByUsername(username);
            dataGridView2.Columns[0].Visible = false;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" && textBox2.Text == "" && textBox3.Text == "" && textBox4.Text == "")
            {
                MessageBox.Show("Select a student from the list.");
            }
            else
            {
                DialogResult dresult = MessageBox.Show("Are you sure you want to reject request?", "Confirmation", MessageBoxButtons.YesNo);
                if (dresult == DialogResult.Yes)
                {
                    int result1 = queueService.QueueValidation(username);
                    if (result1 > 0)
                    {
                        
                        int result2 = registrationService.RemoveRegistrationByUserName(textBox2.Text, username);
                        
                        if (result2 > 0)
                        {
                            int result = registrationService.RegistrationValidationUser(username);
                            //MessageBox.Show(Convert.ToString(result));
                            if (result == 0)
                            {
                                queueService.RemoveQueue(username);
                                MessageBox.Show(username + " Rejected.");
                                UpdateGridView();
                                textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = string.Empty;
                            }
                            else
                            {
                                MessageBox.Show(username + " Rejected.");
                                UpdateGridView();
                                textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = string.Empty;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Error1");
                        }


                    }
                    else
                    {
                        MessageBox.Show("No student found, maybe student has left the Line.");
                        textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = string.Empty;
                    }
                }
                else
                {
                    textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = string.Empty;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" && textBox2.Text == "" && textBox3.Text == "" && textBox4.Text == "")
            {
                MessageBox.Show("Select a student from the list.");
            }
            else
            {
                int count = sectionService.GetCountBySection(textBox2.Text, textBox3.Text);
                if(count == 40)
                {
                    MessageBox.Show("Section limit reached.");
                }
                else
                {
                    int result1 = queueService.QueueValidation(username);
                    if (result1 > 0)
                    {
                        result1 = registeredService.AddStudent(username, textBox2.Text,textBox3.Text);
                        //MessageBox.Show(Convert.ToString(result1));
                       
                        int result2 = registrationService.RemoveRegistrationByUserName(textBox2.Text, username);
                        if (result2 > 0 && result1 == 1 )
                        {
                            result2 = sectionService.EditSection(textBox2.Text, textBox3.Text, ++count);
                            int result = registrationService.RegistrationValidationUser(username);
                            if (result == 0)
                            {
                                queueService.RemoveQueue(username);
                                MessageBox.Show(username + " Added.");
                                UpdateGridView();
                                textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = string.Empty;
                            }
                            else
                            {
                                MessageBox.Show(username + " Added.");
                                
                                UpdateGridView();
                                textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = string.Empty;
                            }
                           
                        }
                        else
                        {
                            MessageBox.Show("Student somehow already managed to register this course.");
                            int result = registrationService.RegistrationValidationUser(username);
                            if (result == 0)
                            {
                                queueService.RemoveQueue(username);
                               
                                UpdateGridView();
                                textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = string.Empty;
                            }
                            else
                            {
                                UpdateGridView();
                                textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = string.Empty;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("No student found, maybe student has left the Line.");
                        textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = string.Empty;
                        int result = registrationService.RegistrationValidationUser(username);
                        if (result == 0)
                        {
                            queueService.RemoveQueue(username);
                            UpdateGridView();
                        }
                        else
                        {
                            UpdateGridView();
                        }
                    }
                    
                   
                    
                }
                
            }
        }

        private void QueueManagement_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void QueueManagement_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = queueService.GetAllQueue();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminHome.Show();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1)
            {

            }
            else
            {
                button1.Enabled = true;
                button2.Enabled = true;
                username = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                dataGridView2.DataSource = registrationService.GetRegistrationByUsername(username);
                dataGridView2.Columns[0].Visible = false;
            }
        }
        
        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex==-1)
            {

            }
            else
            {
                textBox1.Text = username;
                textBox2.Text = dataGridView2.Rows[e.RowIndex].Cells[2].Value.ToString();
                textBox3.Text = dataGridView2.Rows[e.RowIndex].Cells[3].Value.ToString();
                textBox4.Text = Convert.ToString(sectionService.GetCountBySection(textBox2.Text, textBox3.Text));
            }
           
        }

    }
}
