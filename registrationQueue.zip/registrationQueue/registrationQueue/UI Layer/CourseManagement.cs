﻿using registrationQueue.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace registrationQueue.UI_Layer
{
    public partial class CourseManagement : Form
    {
        CourseService courseService;
        SectionService sectionService;
        AdminHome adminHome;
        public CourseManagement(AdminHome adminHome)
        {
            InitializeComponent();
            this.courseService = new CourseService();
            this.sectionService = new SectionService();
            this.adminHome = adminHome;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = courseService.GetAllCourses();
            
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        { 
            string coursename = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            dataGridView2.DataSource = sectionService.GetAllSectionNames(coursename);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminHome.Show();
        }

        private void CourseManagement_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void CourseManagement_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = courseService.GetAllCourses();
        }
    }
}
