﻿using registrationQueue.Entities;
using registrationQueue.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace registrationQueue.Repository
{
    public class SectionRepository : IRepository<Section>
    {
        DataAccess dataAccess;
        public SectionRepository()
        {
            this.dataAccess = new DataAccess();
        }

        public List<Section> GetAll(string sec)
        {
            dataAccess = new DataAccess();

            string sql = "SELECT * FROM " + sec ;
            SqlDataReader reader = dataAccess.GetData(sql);
            List<Section> sectionList = new List<Section>();
            while (reader.Read())
            {
                Section section = new Section();
                section.SecId = Convert.ToInt32(reader["SectionId"]);
                section.SecName = reader["Section"].ToString();
                section.Status =Convert.ToInt32(reader["Status"]);
                section.Count = Convert.ToInt32(reader["Count"]);
                section.Limit = Convert.ToInt32(reader["Limit"]);
                sectionList.Add(section);
            }
            dataAccess.Dispose();
            return sectionList;
        }
        public List<string> GetAllSectionNames(string sec)
        {
            dataAccess = new DataAccess();
            string sql = "SELECT Section FROM " + sec;
            SqlDataReader reader = dataAccess.GetData(sql);
            List<string> sectionList = new List<string>();
            while (reader.Read())
            {
                sectionList.Add(reader["Section"].ToString());
            }
            dataAccess.Dispose();
            return sectionList;
        }
        public Section Get(string sec, int id)
        {
            dataAccess = new DataAccess();
            string sql = "SELECT * FROM "+ sec +" WHERE SectionId=" + id;
            SqlDataReader reader = dataAccess.GetData(sql);
            reader.Read();
            Section section = new Section();
            section.SecId = Convert.ToInt32(reader["SectionId"]);
            section.SecName = reader["Section"].ToString();
            section.Status = Convert.ToInt32(reader["Status"]);
            section.Count = Convert.ToInt32(reader["Count"]);
            section.Limit = Convert.ToInt32(reader["Limit"]);
            dataAccess.Dispose();
            return section;
        }

        public int GetCountBySection(string sec,string name)
        {
            dataAccess = new DataAccess();
            string sql = "SELECT Count FROM "+ sec +" WHERE Section='" + name + "'";
            SqlDataReader reader = dataAccess.GetData(sql);
            reader.Read();
            int result = Convert.ToInt32(reader["Count"]);

            dataAccess.Dispose();
            return result;

        }

        public int GetIdBySection(string sec, string name)
        {
            dataAccess = new DataAccess();
            string sql = "SELECT SecId FROM " + sec + " WHERE Section='" + name + "'";
            SqlDataReader reader = dataAccess.GetData(sql);
            reader.Read();
            int result = Convert.ToInt32(reader["SecId"]);

            dataAccess.Dispose();
            return result;

        }
        public int Insert(string sec, Section entity)
        {
            dataAccess = new DataAccess();
            string sql = "INSERT INTO "+ sec + "(Section,SectionId,Status,Count,Limit) VALUES('" + entity.SecName + "'," + entity.SecId + "," + entity.Status + "," + entity.Count + "," + entity.Limit + ")";
            int result = dataAccess.ExecuteQuery(sql);
            dataAccess.Dispose();
            return result;
        }

        public int Update(string sec, Section entity)
        {
            dataAccess = new DataAccess();
            string sql = "UPDATE " + sec + " SET Count=" + entity.Count + " WHERE Section='" + entity.SecName + "'"; 
            int result = dataAccess.ExecuteQuery(sql);
            dataAccess.Dispose();
            return result;
        }

        public int Delete(string sec, string name)
        {
            dataAccess = new DataAccess();
            string sql = "DELETE FROM " + sec + " WHERE Section='" + name+ "'";
            int result = dataAccess.ExecuteQuery(sql);
            MessageBox.Show(Convert.ToString(result));
            dataAccess.Dispose();
            return result;
        }

        public List<Section> GetAll()
        {
            throw new NotImplementedException();
        }

        public Section Get(int id)
        {
            throw new NotImplementedException();
        }

        public int Insert(Section entity)
        {
            throw new NotImplementedException();
        }

        public int Update(Section entity)
        {
            throw new NotImplementedException();
        }

        public int Delete(string name)
        {
            throw new NotImplementedException();
        }

        public Section Get(string username)
        {
            throw new NotImplementedException();
        }
        public List<Section> GetByUserName(string username)
        {
            throw new NotImplementedException();
        }
    }
}
