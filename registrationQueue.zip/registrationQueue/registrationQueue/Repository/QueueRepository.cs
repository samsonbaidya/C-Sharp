﻿using registrationQueue.Entities;
using registrationQueue.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace registrationQueue.Repository
{
    class QueueRepository : IRepository<Queue>
    {
        DataAccess dataAccess;
        public QueueRepository()
        {
            dataAccess = new DataAccess();
        }
        public List<Queue> GetAll()
        {
            dataAccess = new DataAccess();
            string sql = "SELECT * FROM Queue";
            SqlDataReader reader = dataAccess.GetData(sql);
            List<Queue> queueList = new List<Queue>();
            while (reader.Read())
            {
                Queue queue = new Queue();
                queue.QueueId = Convert.ToInt32(reader["QueueId"]);
                queue.UserName = reader["Username"].ToString();
                queueList.Add(queue);
            }
            dataAccess.Dispose();
            return queueList;
        }
        public Queue Get(string username)
        {
            dataAccess = new DataAccess();
            string sql = "SELECT * FROM Queue WHERE Username='" + username + "'";
            SqlDataReader reader = dataAccess.GetData(sql);
            reader.Read();
            Queue queue = new Queue();
            queue.UserName = reader["Username"].ToString();
            queue.QueueId = Convert.ToInt32(reader["QueueId"]);
            dataAccess.Dispose();
            return queue;
        }
        public List<Queue> GetByUserName(string username)
        {
            dataAccess = new DataAccess();
            string sql = "SELECT * FROM Queue WHERE Username='" + username + "'";
            SqlDataReader reader = dataAccess.GetData(sql);
            List<Queue> queueList = new List<Queue>();
            while (reader.Read())
            {
                Queue queue = new Queue();
                queue.UserName = reader["Username"].ToString();
                queue.QueueId = Convert.ToInt32(reader["QueueId"]);
                queueList.Add(queue);
            }
            dataAccess.Dispose();
            return queueList;
        }
     
        public int QueueValidation(Queue queue)
        {
            dataAccess = new DataAccess();
            string sql = "SELECT * FROM Queue WHERE Username='" + queue.UserName + "'";
            SqlDataReader reader = dataAccess.GetData(sql);
            if (reader.HasRows)
            {
                dataAccess.Dispose();
                return 1;
            }
            else
            {
                dataAccess.Dispose();
                return 0;
            }


        }
        public List<Queue> GetAll(string sec)
        {
            throw new NotImplementedException();
        }

        public Queue Get(int id)
        {
            throw new NotImplementedException();
        }

        public Queue Get(string sec, int id)
        {
            throw new NotImplementedException();
        }

        public int Insert(Queue entity)
        {
            dataAccess = new DataAccess();
            string sql = "INSERT INTO Queue (Username) VALUES ('" + entity.UserName + "')";
            int result = dataAccess.ExecuteQuery(sql);
            dataAccess.Dispose();
            return result;
        }

        public int Insert(string sec, Queue entity)
        {
            throw new NotImplementedException();
        }

        public int Update(Queue entity)
        {
            throw new NotImplementedException();
        }

        public int Update(string sec, Queue entity)
        {
            throw new NotImplementedException();
        }

        public int Delete(string name)
        {
            dataAccess = new DataAccess();
            string sql = "DELETE FROM Queue WHERE Username ='" + name + "'";
            int result = dataAccess.ExecuteQuery(sql);
            dataAccess.Dispose();
            return result;
        }

        public int Delete(string sec, string name)
        {
            throw new NotImplementedException();
        }
    }
}
