﻿using registrationQueue.Entities;
using registrationQueue.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace registrationQueue.Repository
{
    public class RegistrationRepository : IRepository<Registration>
    {
        DataAccess dataAccess;
        public RegistrationRepository()
        {
            dataAccess = new DataAccess();
        }
        public List<Registration> GetAll()
        {
            dataAccess = new DataAccess();
            string sql = "SELECT * FROM Registration";
            SqlDataReader reader = dataAccess.GetData(sql);
            List<Registration> regList = new List<Registration>();
            while (reader.Read())
            {
                Registration reg = new Registration();
                reg.RegId = Convert.ToInt32(reader["RegId"]);
                reg.UserName = reader["Username"].ToString();
                reg.CourseName = reader["CourseName"].ToString();
                reg.SecName = reader["SectionName"].ToString();
                regList.Add(reg);
            }
            dataAccess.Dispose();
            return regList;
        }
        public Registration Get(string username)
        {
            dataAccess = new DataAccess();
            string sql = "SELECT * FROM Registration WHERE Username='" + username + "'";
            SqlDataReader reader = dataAccess.GetData(sql);
            reader.Read();
            Registration reg = new Registration();
            reg.UserName = reader["Username"].ToString();
            reg.CourseName = reader["CourseName"].ToString();
            reg.SecName = reader["SectionName"].ToString();
            dataAccess.Dispose();
            return reg;
        }
        public List<Registration> GetByUserName(string username)
        {
            dataAccess = new DataAccess();
            string sql = "SELECT * FROM Registration WHERE Username='" + username + "'";
            SqlDataReader reader = dataAccess.GetData(sql);
            List<Registration> regList = new List<Registration>();
            while (reader.Read())
            {
                Registration reg = new Registration();
                reg.UserName = reader["Username"].ToString();
                reg.CourseName = reader["CourseName"].ToString();
                reg.SecName = reader["SectionName"].ToString();
                regList.Add(reg);
            }
            dataAccess.Dispose();
            return regList;
        }
        public int RegistrationMethod(Registration reg)
        {
            dataAccess = new DataAccess();
            string sql = "INSERT INTO Registration (Username,CourseName,SectionName) VALUES ('" + reg.UserName + "','" + reg.CourseName + "','" + reg.SecName + "')";
            int result = dataAccess.ExecuteQuery(sql);
            dataAccess.Dispose();
            return result;


        }
        public int RegistrationValidation(Registration reg)
        {
            dataAccess = new DataAccess();
            string sql = "SELECT * FROM Registration WHERE Username='" + reg.UserName + "' AND CourseName = '" + reg.CourseName + "'";
            SqlDataReader reader = dataAccess.GetData(sql);
            if (reader.HasRows)
            {
                dataAccess.Dispose();
                return 1;
            }
            else
            {
                dataAccess.Dispose();
                return 0;
            }


        }
        public int RegistrationValidationUser(Registration reg)
        {
            dataAccess = new DataAccess();
            string sql = "SELECT * FROM Registration WHERE Username='" + reg.UserName + "'";
            SqlDataReader reader = dataAccess.GetData(sql);
            if (reader.HasRows)
            {
                dataAccess.Dispose();
                return 1;
            }
            else
            {
                dataAccess.Dispose();
                return 0;
            }


        }
        public List<Registration> GetAll(string sec)
        {
            throw new NotImplementedException();
        }

        public Registration Get(int id)
        {
            throw new NotImplementedException();
        }

        public Registration Get(string sec, int id)
        {
            throw new NotImplementedException();
        }

        public int Insert(Registration entity)
        {
            throw new NotImplementedException();
        }

        public int Insert(string sec, Registration entity)
        {
            throw new NotImplementedException();
        }

        public int Update(Registration entity)
        {
            throw new NotImplementedException();
        }

        public int Update(string sec, Registration entity)
        {
            throw new NotImplementedException();
        }

        public int Delete(string name)
        {
            dataAccess = new DataAccess();
            string sql = "DELETE FROM Registration WHERE CourseName='" + name + "'";
            int result = dataAccess.ExecuteQuery(sql);
            dataAccess.Dispose();
            return result;
        }
        public int DeleteByUser(string username)
        {
            dataAccess = new DataAccess();
            string sql = "DELETE FROM Registration WHERE Username='" + username+ "'";
            int result = dataAccess.ExecuteQuery(sql);
            dataAccess.Dispose();
            return result;
        }
        public int Delete(string sec, string name)
        {
            dataAccess = new DataAccess();
            string sql = "DELETE FROM Registration WHERE Username='" + name + "' AND CourseName='"+ sec +"'";
            int result = dataAccess.ExecuteQuery(sql);
            dataAccess.Dispose();
            return result;
        }

    }
}
