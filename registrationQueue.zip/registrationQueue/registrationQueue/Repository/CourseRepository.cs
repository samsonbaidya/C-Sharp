﻿using registrationQueue.Entities;
using registrationQueue.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace registrationQueue.Repository
{
   
    public class CourseRepository : IRepository<Course>
    {
        DataAccess dataAccess;
        public CourseRepository()
        {
            this.dataAccess = new DataAccess();
        }
        public List<Course> GetAll()
        {
            dataAccess = new DataAccess();
            string sql = "SELECT * FROM Course";
            SqlDataReader reader = dataAccess.GetData(sql);
            List<Course> courseList = new List<Course>();
            while (reader.Read())
            {
                Course course = new Course();
                course.CourseId = Convert.ToInt32(reader["CourseId"]);
                course.CourseName = reader["CourseName"].ToString();
                courseList.Add(course);
            }
            dataAccess.Dispose();
            return courseList;
        }
        public List<string> GetAllCourseNames()
        {
            dataAccess = new DataAccess();
            string sql = "SELECT CourseName FROM Course";
            SqlDataReader reader = dataAccess.GetData(sql);
            List<string> courseList = new List<string>();
            while (reader.Read())
            {
                courseList.Add(reader["CourseName"].ToString());
            }
            dataAccess.Dispose();
            return courseList;

        }

        public int GetIdByName(string name)
        {
            dataAccess = new DataAccess();
            string sql = "SELECT CourseId FROM Course WHERE CourseName='" + name + "'";
            SqlDataReader reader = dataAccess.GetData(sql);
            reader.Read();
            int result = Convert.ToInt32(reader["CourseId"]);

            dataAccess.Dispose();
            return result;

        }
        public Course Get(int id)
        {
            dataAccess = new DataAccess();
            string sql = "SELECT * FROM Course WHERE CourseId=" + id;
            SqlDataReader reader = dataAccess.GetData(sql);
            reader.Read();
            Course course = new Course();
            course.CourseId = Convert.ToInt32(reader["CourseId"]);
            course.CourseName = reader["CourseName"].ToString();
            dataAccess.Dispose();
            return course;
        }

        public int Insert(Course entity)
        {
            dataAccess = new DataAccess();
            string sql = "INSERT INTO Course(CourseName) VALUES('" + entity.CourseName + "')";
            int result = dataAccess.ExecuteQuery(sql);
            dataAccess.Dispose();
            return result;
        }

        public int Update(Course entity)
        {
            dataAccess = new DataAccess();
            string sql = "UPDATE Course SET CategoryName='" + entity.CourseName + "' WHERE CourseId=" + entity.CourseId;
            int result = dataAccess.ExecuteQuery(sql);
            dataAccess.Dispose();
            return result;
        }

        public int Delete(string name)
        {
            dataAccess = new DataAccess();
            string sql = "DELETE FROM Course WHERE CourseName='" + name +"'";
            int result = dataAccess.ExecuteQuery(sql);
            dataAccess.Dispose();
            return result;
        }

        public List<Course> GetAll(string sec)
        {
            throw new NotImplementedException();
        }

        public Course Get(string sec, int id)
        {
            throw new NotImplementedException();
        }

        public int Insert(string sec, Course entity)
        {
            throw new NotImplementedException();
        }

        public int Update(string sec, Course entity)
        {
            throw new NotImplementedException();
        }

        public int Delete(string sec, string name)
        {
            throw new NotImplementedException();
        }

        public Course Get(string username)
        {
            throw new NotImplementedException();
        }

        public List<Course> GetByUserName(string username)
        {
            throw new NotImplementedException();
        }
    }
}
