﻿using registrationQueue.Entities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace registrationQueue.Repository
{
    public class SignupRepository
    {
        DataAccess dataAccess;
        public SignupRepository()
        {
            dataAccess = new DataAccess();
        }

        public int SignupMethod(User user)
        {
            if (user.UserType == 1)
            {
                dataAccess = new DataAccess();
                string sql = "SELECT * FROM Admin WHERE UserName = '" + user.Username + "' AND Name = '" + user.Name + "'";
                SqlDataReader reader = dataAccess.GetData(sql);
                reader.Read();
                if (reader.HasRows) 
                {
                    dataAccess.Dispose();
                    //result = 0;
                    dataAccess = new DataAccess();
                    sql = "INSERT INTO Credentials(Username,Password,UserType) VALUES('" + user.Username + "','" + user.Password + "'," + user.UserType + ")";
                    int result = dataAccess.ExecuteQuery(sql);
                    dataAccess.Dispose();
                    if (result > 0)
                    {
                        return 1;
                    }
                    else { return 0; }
                }
                else
                {
                    dataAccess.Dispose();
                    return -1;
                }
            }
            else
            {
                dataAccess = new DataAccess();
                string sql = "SELECT * FROM Student WHERE UserName = '" + user.Username + "' AND Name = '" + user.Name + "'";
                SqlDataReader reader = dataAccess.GetData(sql);
                reader.Read();
                if (reader.HasRows)
                {
                    dataAccess.Dispose();
                    //result = 0;
                    dataAccess = new DataAccess();
                    sql = "INSERT INTO Credentials(Username,Password,UserType) VALUES('" + user.Username + "','" + user.Password + "'," + user.UserType + ")";
                    int result = dataAccess.ExecuteQuery(sql);
                    dataAccess.Dispose();
                    if (result > 0)
                    {
                        return 1;
                    }
                    else { return 0; }
                }
                else
                {
                    dataAccess.Dispose();
                    return -2;
                }
            }
            

        }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
    }
}                                                                                                                                           