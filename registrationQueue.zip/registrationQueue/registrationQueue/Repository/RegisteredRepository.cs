﻿using registrationQueue.Entities;
using registrationQueue.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace registrationQueue.Repository
{
    public class RegisteredRepository : IRepository<Registration>
    {
        DataAccess dataAccess;
        public RegisteredRepository()
        {
            dataAccess = new DataAccess();
        }

        public int AddStudent(Registration user)
        {
            dataAccess = new DataAccess();
            string sql = "SELECT * FROM Registered WHERE Username='" + user.UserName + "' AND Coursename= '"+ user.CourseName+"'";
            SqlDataReader reader = dataAccess.GetData(sql);
            reader.Read();
            if (reader.HasRows)
            {
                dataAccess.Dispose();
                return 5;
            }
            else 
            {
                dataAccess = new DataAccess();
                sql = "INSERT INTO Registered (Username, Coursename,Sectionname) VALUES('" + user.UserName + "','"+ user.CourseName + "','"+ user.SecName +"')";
                int result = dataAccess.ExecuteQuery(sql);
                dataAccess.Dispose();
                if (result > 0)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
           
        }

        public int Delete(string name)
        {
            throw new NotImplementedException();
        }

        public int Delete(string sec, string name)
        {
            throw new NotImplementedException();
        }

        public Registration Get(int id)
        {
            throw new NotImplementedException();
        }

        public Registration Get(string sec, int id)
        {
            throw new NotImplementedException();
        }

        public Registration Get(string username)
        {
            throw new NotImplementedException();
        }

        public List<Registration> GetAll()
        {
            throw new NotImplementedException();
        }

        public List<Registration> GetAll(string sec)
        {
            throw new NotImplementedException();
        }

        public List<Registration> GetByUserName(string username)
        {
            dataAccess = new DataAccess();
            string sql = "SELECT * FROM Registered WHERE Username='" + username + "'";
            SqlDataReader reader = dataAccess.GetData(sql);
            List<Registration> registeredList = new List<Registration>();
            while (reader.Read())
            {
                Registration registration = new Registration();
                registration.CourseName = reader["Coursename"].ToString();
                registration.SecName = reader["Sectionname"].ToString();
                registeredList.Add(registration);
            }
            dataAccess.Dispose();
            return registeredList;
        }

        public int Insert(Registration entity)
        {
            throw new NotImplementedException();
        }

        public int Insert(string sec, Registration entity)
        {
            throw new NotImplementedException();
        }

        public int Update(Registration entity)
        {
            throw new NotImplementedException();
        }

        public int Update(string sec, Registration entity)
        {
            throw new NotImplementedException();
        }
    }
}
