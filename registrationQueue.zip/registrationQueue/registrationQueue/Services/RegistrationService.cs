﻿using registrationQueue.Entities;
using registrationQueue.Interfaces;
using registrationQueue.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace registrationQueue.Services
{
    public class RegistrationService
    {
        IRepository<Registration> repo;
        RegistrationRepository regRepo;
        public RegistrationService()
        {
            this.regRepo = new RegistrationRepository();
            this.repo = new RegistrationRepository();
        }
        public List<Registration> GetAllRegistration()
        {
            return repo.GetAll();
        }
        public List<Registration> GetRegistrationByUsername(string username)
        {
            return repo.GetByUserName(username);
        }
        public int RegistrationMethod(string userName, string courseName, string secName)
        {
            return regRepo.RegistrationMethod(new Registration() { UserName = userName, CourseName = courseName, SecName = secName });
        }
        public int RegistrationValidation(string username, string coursename)
        {
            return regRepo.RegistrationValidation(new Registration() { UserName = username, CourseName = coursename });
        }
        public int RegistrationValidationUser(string username)
        {
            return regRepo.RegistrationValidationUser(new Registration() { UserName = username });
        }
        public int RemoveRegistration(string name)
        {
            int result = repo.Delete(name);
            return result;
        }

        public int RemoveRegistrationByUserName(string username)
        {
            int result = regRepo.DeleteByUser(username);
            return result;
        }
        public int RemoveRegistrationByUserName(string course,string username)
        {
            int result = regRepo.Delete(course,username);
            return result;
        }
    }
}
