﻿using registrationQueue.Entities;
using registrationQueue.Interfaces;
using registrationQueue.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace registrationQueue.Services
{
    public class SectionService
    {
        IRepository<Section> repo;
        SectionRepository sectionRepo;
        public SectionService()
        {
            this.repo = new SectionRepository();
            this.sectionRepo = new SectionRepository();
        }

        public List<Section> GetAllSection()
        {
            return repo.GetAll();
        }
        public List<string> GetAllSectionNames(string sec)
        {
            return sectionRepo.GetAllSectionNames(sec);
        }
        public List<Section> GetSectionById(int id)
        {
            var data = repo.Get(id);
            Section section = new Section();
            section.SecId = data.SecId;
            section.SecName = data.SecName;
            section.Status = data.Status;
            section.Count = data.Count;
            section.Limit = data.Limit;
            List<Section> list = new List<Section>();
            list.Add(section);
            return list;
        }
        public int GetCountBySection(string sec, string name)
        {
            var data = sectionRepo.GetCountBySection(sec,name);

            return data;
        }
        public int GetIdBySection(string sec, string name)
        {
            var data = sectionRepo.GetIdBySection(sec, name);

            return data;
        }
        public int AddSection(string name, int status, int count, int limit)
        {
            //Product product = new Product();
            //product.Name = name;
            //product.Price = price;
            int result = repo.Insert(new Section() { SecName = name, Status = status, Count = count, Limit = limit });
            return result;
        }

        public int EditSection(string sec, string name, int count)
        {
            //Product product = new Product();\
            //Product.Id = id;
            //product.Name = name;
            //product.Price = price;
            int result = repo.Update(sec, new Section() {SecName = name, Count = count});
            return result;
        }

        public int RemoveSection(string sec ,string name)
        {
            int result = repo.Delete(sec,name);
            return result;
        }
    }
}
