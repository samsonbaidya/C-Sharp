﻿using registrationQueue.Entities;
using registrationQueue.Interfaces;
using registrationQueue.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace registrationQueue.Services
{
    class RegisteredService
    {
        IRepository<Registration> repo;
        RegisteredRepository registeredRepo;
        public RegisteredService()
        {
            registeredRepo = new RegisteredRepository();
            repo = new RegisteredRepository();
        }

        public int AddStudent(string username , string coursename, string secname)
        {
            return registeredRepo.AddStudent(new Registration() { UserName = username , CourseName = coursename , SecName = secname });
        }
        public List<Registration> GetRegisteredByUsername(string username)
        {
            return repo.GetByUserName(username);
        }
    }
}
