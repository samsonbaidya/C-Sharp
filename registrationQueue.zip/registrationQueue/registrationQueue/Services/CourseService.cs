﻿using registrationQueue.Entities;
using registrationQueue.Interfaces;
using registrationQueue.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace registrationQueue.Services
{
    public class CourseService
    {
        IRepository<Course> repo;
        CourseRepository courseRepo;
        public CourseService()
        {
            this.repo = new CourseRepository();
            this.courseRepo = new CourseRepository();
        }

        public List<Course> GetAllCourses()
        {
            return repo.GetAll();
        }
        public List<string> GetAllCourseNames()
        {
            return courseRepo.GetAllCourseNames();
        }
        public List<Course> GetCourseById(int id)
        {
            var data = repo.Get(id);
            Course course = new Course();
            course.CourseId = data.CourseId;
            course.CourseName = data.CourseName;
            List<Course> list = new List<Course>();
            list.Add(course);
            return list;
        }
        public int GetIdByName(string name)
        {
            var data = courseRepo.GetIdByName(name);

            return data;
        }

        public int AddCourse(string name)
        {
            //Product product = new Product();
            //product.Name = name;
            //product.Price = price;
            int result = repo.Insert(new Course() { CourseName = name });
            return result;
        }

        public int EditCourse(int id, string name)
        {
            //Product product = new Product();\
            //Product.Id = id;
            //product.Name = name;
            //product.Price = price;
            int result = repo.Update(new Course() { CourseId = id, CourseName = name });
            return result;
        }

        public int RemoveCourse(string name)
        {
            int result = repo.Delete(name);
            return result;
        }
    }
}
