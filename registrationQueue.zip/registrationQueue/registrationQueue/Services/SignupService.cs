﻿using registrationQueue.Entities;
using registrationQueue.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace registrationQueue.Services
{
    public class SignupService
    {
        SignupRepository signupRepo;
        public SignupService()
        {
            signupRepo = new SignupRepository();
        }
        public int UserRegistration(string name, string email,int phone, string username, string password, int userType)
        {
            return signupRepo.SignupMethod(new User() { Name = name, Email = email, Phone = phone, Username = username, Password = password, UserType = userType });
        }
    }
}
