﻿using registrationQueue.Entities;
using registrationQueue.Interfaces;
using registrationQueue.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace registrationQueue.Services
{
    class QueueService
    {
        IRepository<Queue> repo;
        QueueRepository queueRepo;
        public QueueService()
        {
            this.queueRepo = new QueueRepository();
            this.repo = new QueueRepository();
        }
        public List<Queue> GetAllQueue()
        {
            return repo.GetAll();
        }
        public List<Queue> GetQueueByUsername(string username)
        {
            return repo.GetByUserName(username);
        }
      
        public int QueueValidation(string username)
        {
            return queueRepo.QueueValidation(new Queue() { UserName = username });
        }
        public int AddQueue(string username)
        {
            int result = repo.Insert(new Queue() { UserName = username });
            return result;
        }
        public int RemoveQueue(string name)
        {
            int result = repo.Delete(name);
            return result;
        }
    }
}
