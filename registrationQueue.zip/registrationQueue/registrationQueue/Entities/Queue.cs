﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace registrationQueue.Entities
{
    public class Queue
    {
        public int QueueId { get; set; }
        public string UserName { get; set; }
    }
}
