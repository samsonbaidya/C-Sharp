﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace registrationQueue.Entities
{
    public class Registration
    {
        public int RegId { get; set; }
        public string UserName { get; set; }
        public string CourseName { get; set; }
        public string SecName { get; set; }
    }
}
