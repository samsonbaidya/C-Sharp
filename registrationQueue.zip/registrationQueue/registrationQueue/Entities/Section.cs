﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace registrationQueue.Entities
{
    public class Section
    {
        public int SecId { get; set; }
        public string SecName { get; set; }
        public int Status { get; set; }
        public int Count { get; set; }
        public int Limit { get; set; }
    }
}
